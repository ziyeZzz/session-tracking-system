package com.se.model;
import java.util.Date;
public class Assignment {

	private String courseID;
	private String assignmentID;
	private Date assignmentDeadline;
	private String assignmentContent;
	
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getAssignmentID() {
		return assignmentID;
	}
	public void setAssignmentID(String assignmentID) {
		this.assignmentID = assignmentID;
	}
	public Date getAssignmentDeadline() {
		return assignmentDeadline;
	}
	public void setAssignmentDeadline(Date assignmentDeadline) {
		this.assignmentDeadline = assignmentDeadline;
	}
	public String getAssignmentContent() {
		return assignmentContent;
	}
	public void setAssignmentContent(String assignmentContent) {
		this.assignmentContent = assignmentContent;
	}
}
