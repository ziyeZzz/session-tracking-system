package com.se.model;

import java.util.Date;


public class Course {
	
	private String courseID;
	private String courseName;
	private String teacherID;
	private Date courseStartDate;
	private Date courseEndDate;
	private String courseRegisterPass;
	
	public String getCourseRegisterPass() {
		return courseRegisterPass;
	}
	public void setCourseRegisterPass(String courseRegisterPass) {
		this.courseRegisterPass = courseRegisterPass;
	}
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}	
	
	public Date getCourseStartDate() {
		return courseStartDate;
	}
	public void setCourseStartDate(Date courseStartDate) {
		this.courseStartDate = courseStartDate;
	}
	
	public Date getCourseEndDate() {
		return courseEndDate;
	}
	public void setCourseEndDate(Date courseEndDate) {
		this.courseEndDate = courseEndDate;
	}
	
	public String getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(String teacherID) {
		this.teacherID = teacherID;
	}	
	
}
