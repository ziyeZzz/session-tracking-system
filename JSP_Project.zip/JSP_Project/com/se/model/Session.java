package com.se.model;

import java.io.File;
import java.io.InputStream;
import java.util.Date;

import com.mysql.jdbc.Blob;


public class Session {

	private String sessionID;
	private String sessionType;
	private String sessionPassword;
	private String sessionAddress;
	private Date sessionDate;
	private Date sessionstartTime;
	private Date sessionendTime;
	private String sessionContent;	
	private String courseID;
	

	
	public String getSessionID() {
		return sessionID;
	}
	public void setSessionID(String sessionID) {
		this.sessionID = sessionID;
	}
	public String getSessionPassword() {
		return sessionPassword;
	}
	public void setSessionPassword(String sessionPassword) {
		this.sessionPassword = sessionPassword;
	}
	public String getCourseID() {
		return courseID;
	}
	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
	public String getSessionContent() {
		return sessionContent;
	}
	public void setSessionContent(String sessionContent) {
		this.sessionContent = sessionContent;
	}
	public String getSessionAddress() {
		return sessionAddress;
	}
	public void setSessionAddress(String sessionAddress) {
		this.sessionAddress = sessionAddress;
	}
	public String getSessionType() {
		return sessionType;
	}
	public void setSessionType(String sessionType) {
		this.sessionType = sessionType;
	}
	public Date getSessionDate() {
		return sessionDate;
	}
	public void setSessionDate(Date sessionDate) {
		this.sessionDate = sessionDate;
	}
	public Date getSessionStartTime() {
		return sessionstartTime;
	}
	public void setSessionStartTime(Date sessionstartTime) {
		this.sessionstartTime = sessionstartTime;
	}
	public Date getSessionEndTime() {
		return sessionendTime;
	}
	public void setSessionEndTime(Date sessionendTime) {
		this.sessionendTime = sessionendTime;
	}

	
	
}
