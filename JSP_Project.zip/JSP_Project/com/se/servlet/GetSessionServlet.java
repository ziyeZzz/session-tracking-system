package com.se.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.SessionDao;
import com.se.dao.impl.SessionDaoImpl;
import com.se.model.Session;

public class GetSessionServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		SessionDao sessionDao = new SessionDaoImpl();
		String sessionID = request.getParameter("sessionID");
		
		Session session = sessionDao.getCurrentSession(sessionID);
		
		
		String sessionPassword = session.getSessionPassword();
		String sessionType =session.getSessionType();
		String sessionAddress =  session.getSessionAddress();
		String sessionContent = session.getSessionContent();
		String sessionDate = session.getSessionDate().toString();
		String sessionStartTime =  session.getSessionStartTime().toString();
		String sessionEndTime =  session.getSessionEndTime().toString();
		
		request.setAttribute("sessionID",sessionID);
		request.setAttribute("sessionPassword",sessionPassword);
		request.setAttribute("sessionType",sessionType);
		request.setAttribute("sessionAddress", sessionAddress);
		request.setAttribute("sessionContent",sessionContent);
		request.setAttribute("sessionDate",sessionDate);
		request.setAttribute("sessionStartTime",sessionStartTime);
		request.setAttribute("sessionEndTime",sessionEndTime);
		
		//RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/error2.htm");		
		RequestDispatcher requestDispatcher=request.getRequestDispatcher("sessionEdit.jsp");
		requestDispatcher.forward(request,response);		
		}
		
	

}
