package com.se.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.CourseDao;
import com.se.dao.impl.CourseDaoImpl;
import com.se.model.Course;

public class AddCourseServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
	  
		String currentTeacherID = request.getSession().getAttribute("userID").toString();
		String courseName = request.getParameter("courseName");
		String courseID = request.getParameter("courseID");
		String courseStartDate = request.getParameter("startDate");
		String courseEndDate = request.getParameter("endDate");
		String courseRegisterPass = request.getParameter("courseRegisterPass");
		Course course = new Course();
		Date sDate = dateFormat(courseStartDate);
		Date eDate = dateFormat(courseEndDate);
		course.setCourseID(courseID);
		course.setCourseName(courseName);
		course.setCourseStartDate(sDate);
		course.setCourseEndDate(eDate);
		course.setCourseRegisterPass(courseRegisterPass);
		course.setTeacherID(currentTeacherID);
		CourseDao courseDao = new CourseDaoImpl();
		String feedback = courseDao.addCourse(course);
		request.getSession().setAttribute("messageAddCourse", feedback);
		
		response.sendRedirect("teacherManagePage.jsp");
		
	}
	
	public static Date dateFormat(String str) {
		 
		Date date=null;
	 	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	 	try{
	 		date = df.parse(str);
	 	}catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
	 	return date;
		 
	 }
}
