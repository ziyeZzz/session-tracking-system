package com.se.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.CourseDao;
import com.se.dao.SessionDao;
import com.se.dao.impl.CourseDaoImpl;
import com.se.dao.impl.SessionDaoImpl;



public class DeleteSessionServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		String sessionID = request.getParameter("sessionID");
		String courseID = request.getParameter("courseID");
		String courseName = request.getParameter("courseName");
		
		SessionDao sessionDao = new SessionDaoImpl();
		String feedback =sessionDao.deleteSession(sessionID);
		 request.getSession().setAttribute("messageDeleteSession", feedback);
		
		response.sendRedirect("courseSessionList.jsp?courseID="+courseID+"&courseName="+courseName);
	}
}
