package com.se.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import com.se.dao.UserDao;
import com.se.dao.impl.UserDaoImpl;
import com.se.model.User;

/**
 * LoginAction is used to deal with the student login information, if user name or password is incorrect,
 * return error html, else turn to the chooseclass.jsp
 * 
 *
 */
public class LoginServlet extends HttpServlet {
	
	//public static String studentID;
	
	//public static String userID;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//studentID=request.getParameter("studentID");
		
		String userID = request.getParameter("userID");
		String password=request.getParameter("password");
		String userType=request.getParameter("userType");
		//HttpSession se=request.getSession();
		String path="login.jsp";		
//		StudentDao studentDao=new StudentDaoImpl();
		UserDao userDao = new UserDaoImpl();
		boolean flag;

		User user=new User();		
//		stu.setStudentID(studentID);
//		stu.setPassword(password);
		user.setUserID(userID);
		user.setPassword(password);
		user.setUserType(userType);
		
		//System.out.println("The enter parameters are:"+username+password);			
		//flag= studentDao.stuLogin(stu);
		
		flag = userDao.userLogin(user);
		System.out.println(flag);
		System.out.println(userType);
		if(flag){
			request.getSession().setAttribute("userID", userID);
			if(userType.equals("teacher")){
			path="teacherManagePage.jsp";
			
			}
			else{
				path="studentMainPage.jsp";
				}
		}
		else{
			request.getSession().setAttribute("messageLogin", "Wrong userName or password, Please input again!");
			
		}
		//response.sendRedirect(path);		
		RequestDispatcher requestDispatcher=request.getRequestDispatcher(path);
		requestDispatcher.forward(request,response);
	}

}
