package com.se.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.AssignmentDao;
import com.se.dao.impl.AssignmentDaoImpl;



public class DeleteAssignmentServlet extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request,response);
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		String assignmentID = request.getParameter("assignmentID");
		String courseID = request.getParameter("courseID");
		String courseName = request.getParameter("courseName");
		
		AssignmentDao assignmentDao = new AssignmentDaoImpl();
		String feedback =assignmentDao.deleteAssignment(assignmentID);
		request.getSession().setAttribute("messageAssignmentDelete", feedback);
		
		response.sendRedirect("courseSessionList.jsp?courseID="+courseID+"&courseName="+courseName);
	}
}
