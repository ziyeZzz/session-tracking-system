package com.se.servlet;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.SessionDao;
import com.se.dao.impl.SessionDaoImpl;
import com.se.model.Session;

public class AddSessionServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private Pattern pattern;
	private Matcher matcher;

	private static final String TIME24HOURS_PATTERN = 
               "([01]?[0-9]|2[0-3]):[0-5][0-9]";
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
		} 
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		String sessionID = request.getParameter("sessionID");
		String sessionPassword = request.getParameter("sessionPassword");
		String sessionType = request.getParameter("sessionType");
		String sessionDate = request.getParameter("sessionDate");
		String sessionAddress = request.getParameter("sessionAddress");
		String sessionContent = request.getParameter("sessionContent");
		String sessionStartTime = request.getParameter("sessionStartTime");
		String sessionEndTime = request.getParameter("sessionEndTime");
		String currentCourseID = request.getParameter("sessionCourseID");
		String currentCourseName = request.getParameter("sessionCourseName");
		//RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/error2.htm");
		
		if (checkParameter(sessionID)&&checkParameter(sessionType)&&checkParameter(sessionDate)
				&&checkParameter(sessionStartTime)&&checkParameter(sessionEndTime)) {
			
			
			
				Date sDate = dateFormat(sessionDate);
				Time sTime = timeFormat(sessionStartTime);
				Time eTime = timeFormat(sessionEndTime);
				
				Session session = new Session();
				session.setSessionID(sessionID);
				session.setSessionPassword(sessionPassword);
				session.setSessionType(sessionType);
				session.setCourseID(currentCourseID);
				session.setSessionAddress(sessionAddress);
				session.setSessionContent(sessionContent);
				session.setSessionDate(sDate);
				session.setSessionStartTime(sTime);
				session.setSessionEndTime(eTime);
				session.setSessionContent(sessionContent);
				
				
				SessionDao sessionDao = new SessionDaoImpl();
				
				String feedback =sessionDao.addSession(session);
				
				request.getSession().setAttribute("messageSessionAdd", feedback);
				
				response.sendRedirect("courseSessionList.jsp?courseID="+currentCourseID+"&courseName="+currentCourseName);
			
		}
		else{
			//dispatcher.include(request, response);
			request.getSession().setAttribute("messageSessionAdd", "Please fillup all area");
			response.sendRedirect("courseSessionList.jsp?courseID="+currentCourseID+"&courseName="+currentCourseName);}
			//System.out.println("missing parameters...");}
		
	}
	
	private boolean checkParameter(String parameter) {

		if (parameter != null && !parameter.equals(""))
			return true;

		return false;

	}
	
	public boolean checkTimeFormat(final String time){
		 
		  pattern = Pattern.compile(TIME24HOURS_PATTERN);
		  matcher = pattern.matcher(time);
		  return matcher.matches();

	  }
	
	 public static Date dateFormat(String str) {
		 	Date date=null;
		 	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		 	try{
		 		date = df.parse(str);
		 	}catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
		 	return date;
		 
	 }
		 
	 public static Time timeFormat(String time){
		 
		 Date date =null;
		 try {
			date = new SimpleDateFormat("HH:mm").parse(time);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
		}
		 return new java.sql.Time(date.getTime());
	 }

}
