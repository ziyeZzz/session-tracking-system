package com.se.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import javax.swing.JOptionPane;

import com.se.dao.AssignmentDao;
import com.se.dao.SessionDao;
import com.se.dao.impl.AssignmentDaoImpl;
import com.se.dao.impl.SessionDaoImpl;

@WebServlet("/uploadServlet")
@MultipartConfig(maxFileSize = 16177215)
// upload file's size up to 16MB
public class FileUploadDBServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// gets values of text fields
		String studentID = request.getSession().getAttribute("userID")
				.toString();
		String assignmentID = request.getParameter("assignmentID");
		String courseID = request.getParameter("courseID");
		String courseName = request.getParameter("courseName");
		InputStream inputStream = null; // input stream of the upload file
		AssignmentDao assignmentDao = new AssignmentDaoImpl();
		String message;
		String fileName= request.getParameter("fileName");
		// obtains the upload file part in this multipart request
		
		String DATETIME = "yyyy-MM-dd HH:mm:ss";
		String nowDateTime = new SimpleDateFormat(DATETIME).format(new Date());
		Part filePart = request.getPart("assignment");
		
		if (filePart != null) {
		//else 
		//	message = "no file uploaded";
		try {
			
			inputStream = filePart.getInputStream();
			/*fileName = getFileName(filePart);*/
			
			message = assignmentDao.upLoad(studentID, assignmentID,nowDateTime, fileName,
					inputStream);
			if (message.equals("File uploaded"))
				request.getSession().setAttribute("uploadFileName", fileName);

			// forwards to the message page
		} catch (Exception e) {
			message = "No file uploaded";
		}}
		else 
			message = "No file uploaded";
		 request.getSession().setAttribute("messageFileUpload", message);
		response.sendRedirect("sessionAssignment.jsp?courseID="+courseID+"&courseName="+courseName+"&assignmentID="+assignmentID);
		/*getServletContext().getRequestDispatcher("/sessionAssignment.jsp")
				.forward(request, response);*/
	}

	private String getFileName(Part p) {
		String header = p.getHeader("content-disposition");
		String filename = header.substring(header.indexOf("filename=\""))
				.split("\"")[1]; // getting filename

		return filename;
	}
}