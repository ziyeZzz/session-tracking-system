package com.se.servlet;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.se.dao.CourseDao;
import com.se.dao.impl.CourseDaoImpl;


import javax.swing.JOptionPane;

public class RegisterToCourseServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		String registerCourseID = request.getParameter("registerCourseID");
		String coursePassword = request.getParameter("coursePassword");
		request.setAttribute("teacherName", request.getParameter("teacherName"));
		String currentUserID_chooseCourse = request.getSession().getAttribute("userID").toString();
		String feedback="";
		CourseDao courseDao = new CourseDaoImpl();
		if(courseDao.checkCoursePass(registerCourseID, coursePassword)){
			feedback = courseDao.registerToCourse(registerCourseID, currentUserID_chooseCourse);
		}
		else
			feedback = "Wrong password";
		request.getSession().setAttribute("messageRegisterCourse", feedback);
		getServletContext().getRequestDispatcher("/courseList.jsp").forward(request, response);
		//response.sendRedirect(request.getHeader("Referer"));
	}

}
