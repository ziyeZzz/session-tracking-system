package com.se.servlet;

import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

import com.se.dao.AssignmentDao;
import com.se.dao.impl.AssignmentDaoImpl;
import com.se.model.Assignment;


public class UpdateAssignmentServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		String assignmentID = request.getParameter("assignmentID");
		String assignmentDate = request.getParameter("assignmentDate");
		String assignmentContent = request.getParameter("assignmentContent");
		String currentCourseID = request.getParameter("assignmentCourseID");
		String currentCourseName = request.getParameter("assignmentCourseName");
		//RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/error2.htm");
		if (checkParameter(assignmentID)&&checkParameter(assignmentDate)&&checkParameter(assignmentContent)) {
			
			
				
				Date sDate = dateFormat(assignmentDate);
								
				AssignmentDao assignmentDao = new AssignmentDaoImpl();
				Assignment a = new Assignment();
				a.setAssignmentContent(assignmentContent);
				a.setAssignmentDeadline(sDate);
				a.setAssignmentID(assignmentID);
				a.setCourseID(currentCourseID);
				
				String feedback =assignmentDao.updateAssignment(a);
				
				
				request.getSession().setAttribute("messageUpdateAssignment", feedback);
				response.sendRedirect("courseSessionList.jsp?courseID="+currentCourseID+"&courseName="+currentCourseName);
			
		}
		else{
			
				request.getSession().setAttribute("messageUpdateAssignment", "Please fillup all area!!");
				response.sendRedirect("courseSessionList.jsp?courseID="+currentCourseID+"&courseName="+currentCourseName); }
			//System.out.println("missing parameters...");}
		
	}
	
	private boolean checkParameter(String parameter) {

		if (parameter != null && !parameter.equals(""))
			return true;

		return false;

	}
	
	
	 public static Date dateFormat(String str) {
		 	Date date=null;
		 	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		 	try{
		 		date = df.parse(str);
		 	}catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			
			}
		 	return date;
		 
	 }

}
