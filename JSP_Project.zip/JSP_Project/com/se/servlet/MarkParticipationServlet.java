package com.se.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.se.model.Session;
import com.se.dao.SessionDao;
import com.se.dao.impl.SessionDaoImpl;
import com.se.dao.impl.UserDaoImpl;
import com.se.dao.UserDao;
import com.se.model.User;

import javax.swing.JOptionPane;

public class MarkParticipationServlet extends HttpServlet {

	/**
	 * <td align="center">&nbsp;<input type="submit"
	 * value="<%=s.getSessionID() %>" name="participateSessionID"></td>
	 */
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String url = request.getParameter("url");
		String query = request.getParameter("query");
		String formerUrl = url + "?" + query;

		String participateSessionID = request.getParameter("sessionID");
		String sessionPassword = request.getParameter("sessionPassword");
		System.out.println(" sessionPassword" + sessionPassword+" sessionID" + participateSessionID);

		String currentStudentID = request.getSession().getAttribute("userID")
				.toString();

		SessionDao sessionDao = new SessionDaoImpl();
		System.out.println("TureOrFalse:"+sessionDao.checkSessionPassword(participateSessionID,
				sessionPassword));
		if (sessionDao.checkSessionPassword(participateSessionID,
				sessionPassword)) {
			String feedback = sessionDao.participateToSession(
					participateSessionID, currentStudentID);
			request.getSession().setAttribute("message", feedback);
		}
		// In the other webpage space, show the webpage titl
		else {
			// request.setAttribute("feedback",
			// " <script laguage='JavaScript'> alert('Wrong password') </script>");
			request.getSession().setAttribute("messageMarkParticipate", "Wrong password");
		}
		response.sendRedirect(formerUrl);

	}

}
