package com.se.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.se.model.Course;
import com.se.dao.CourseDao;
import com.se.dao.impl.CourseDaoImpl;
import com.se.dao.impl.UserDaoImpl;
import com.se.dao.UserDao;
import com.se.model.User;

public class SearchTeacherCourseServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		
		String teacherName = request.getParameter("teacherList");
		System.out.println("The teacherName is "+teacherName);
		UserDao userDao = new UserDaoImpl();
		User currentTeacher = userDao.getCurrentUserByName(teacherName);
		String currentTeacherID = currentTeacher.getUserID();
		CourseDao courseDao = new CourseDaoImpl();
		List<Course> teacherCourse = courseDao.getTeacherCourseList(currentTeacherID);
		
		request.setAttribute("teacherCourse", teacherCourse);
		request.setAttribute("teacherName", teacherName);
		request.getRequestDispatcher("chooseCourse.jsp").forward(request, response);
	}

}
