package com.se.servlet;
 
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class MarkAssignmentServlet extends HttpServlet {
  
  
	private static final long serialVersionUID = 1L;
	// database connection settings
    private String dbURL = "jdbc:mysql://mysql.cc.puv.fi:3306/e1101668_JSP";
    private String dbUser = "e1101668";
    private String dbPass = "NRraDW9QpuMF";
    public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	} 
    public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
        // get upload id from URL's parameters
       
        String studentID = request.getParameter("studentID");
        String assignmentAccept = request.getParameter("assignmentAccept");
        String assignmentID = request.getParameter("assignmentID");
         System.out.println("stID is"+studentID+" "+assignmentID);
        Connection conn = null; // connection to the database
        String message="";
         
        try {
            // connects to the database
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
 
            // queries the database
            String sql = "update stu_course_assignment SET teacherMark= ? WHERE studentID = ? and assignmentID = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, assignmentAccept);
            statement.setString(2, studentID);
            statement.setString(3, assignmentID);
 
            statement.executeUpdate();
            message="Mark Success!";
            
           
        } catch (SQLException ex) {
            ex.printStackTrace();
            message = "SQL Error: " + ex.getMessage();
        }  finally {
            if (conn != null) {
                // closes the database connection
                try {
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
                request.getSession().setAttribute("messageMarkAssignment", message);
                response.sendRedirect(request.getHeader("referer"));    
            }          
        }
    }
}