package com.se.dao;

import java.io.InputStream;
import java.util.List;





import com.se.model.Session;

public interface SessionDao {

	public List<Session> getSessionList(String courseID);
	public String addSession(Session session);
	public String deleteSession(String sessionID);
	public boolean checkSessionPassword(String sessionID,String sessionPassword);
	public String participateToSession(String participateSessionID, String currentStudentID);
	public boolean checkSessionParticipateList(String sessionID,String studentID);
	public  List<Session> getStudentRegisterSessionID(String studentID, String courseID);
	public Session getCurrentSession(String sessionID);
	public String updateSession(Session s);
}
