package com.se.dao;

import java.util.List;

import com.se.model.Course;
import com.se.model.User;

public interface UserDao {
	
	public boolean userLogin(User user);
	public List<User> getUserList();
	public void deleteUser(String userID);
	public void addUser(User a);
	public List<String> getTeacherUserList();
	public List<User> getStudentUserList();
	public User getCurrentUser(String userID);
	public User getCurrentUserByName(String userName);
	public List<User> getCourseStudent(String courseID);
	public String getCurrentUserType(String userID);
	public List<User> getStuAssignmentList(String assignmentID);
	public List<User> getSessionParticipateStudent(String sessionID);
	
}
