package com.se.dao.impl;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

import com.mysql.jdbc.PreparedStatement;
import com.se.dao.AssignmentDao;
import com.se.model.Assignment;
import com.se.model.Session;

public class AssignmentDaoImpl implements AssignmentDao {

	private DB db = new DB();

	public String addAssignment(String courseID, String assignmentID,
			Date assignmentDeadline, String assignmentContent) {

		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "";
		try {
			conn = db.getConn();
			String sql = "insert into course_assignment values (?,?,?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, courseID);
			pstmt.setString(2, assignmentID);
			pstmt.setDate(3, new java.sql.Date(assignmentDeadline.getTime()));
			pstmt.setString(4, assignmentContent);
			pstmt.executeUpdate();
			feedback = "Success added assignment:" + assignmentID
					+ " in course:" + courseID;
		} catch (SQLException e1) {
			e1.printStackTrace();
			feedback = e1.getMessage();
		} catch (Exception e) {
			e.printStackTrace();
			feedback = e.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
	}
public String updateAssignment(Assignment a) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "Sorry some error here, check your courseID if it duplicated";
		try {
			conn = db.getConn();
			String assignmentID = a.getAssignmentID();
			String courseID = a.getCourseID();
			
			String assignmentDeadline = new java.sql.Date (a.getAssignmentDeadline().getTime())+"";

			String assignmentContent = a.getAssignmentContent();
		
			String sql = "update course_assignment set assignmentDeadline='"+assignmentDeadline+"',assignmentContent='"+assignmentContent+"'"
					+ " where assignmentID='"+assignmentID+"' and courseID ='"+courseID+"'";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
		//	pstmt.setString(1, c.getCourseID());
//			pstmt.setString(2, c.getCourseName());
//			pstmt.setDate(1, new java.sql.Date (c.getCourseStartDate().getTime()));
//			pstmt.setDate(2, new java.sql.Date (c.getCourseEndDate().getTime()));
//			pstmt.setString(3, c.getCourseID());
			DB.executeUpdate(pstmt, sql);	
			conn.close();
			pstmt.close();
			
			feedback = "Updated Assignment Success";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			feedback=e.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
		
	}
	public List<Assignment> getAssignmentList(String courseID) {
		// TODO Auto-generated method stub

		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from course_assignment where courseID = '"
				+ courseID + "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Assignment> assignments = new ArrayList<Assignment>();
		try {
			while (rs.next()) {
				Assignment a = getAssignmentFromRs(rs);
				assignments.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return assignments;
	}

	/*public Assignment getStudentUploadAss(String studentID, String assignmentID, String fileName){
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		File file = null;
		conn = db.getConn();
		String sql = "select assignment from stu_course_assignment where studentID='"
				+ studentID
				+ "' and "
				+ "assignmentID = '"
				+ assignmentID
				+ "' and fileName='" + fileName + "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		Assignment assignment = new Assignment();
		try {
			while (rs.next()) {
				assignment  = getAssignmentFromRs(rs);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return assignment;
	}
	*/
	public File downLoad(String studentID, String assignmentID){
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		File file = null;
		conn = db.getConn();
		String sql = "select assignment from stu_course_assignment where studentID='"
				+ studentID
				+ "' and "
				+ "assignmentID = '"
				+ assignmentID
				+ "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		try {
				while (rs.next()) { // for each row
					// take the blob
					Blob blob = rs.getBlob(1);
					BufferedInputStream is = new BufferedInputStream(
							blob.getBinaryStream());
					FileOutputStream fos = new FileOutputStream(file);
					// you can set the size of the buffer
					byte[] buffer = new byte[2048];
					int r = 0;
					while ((r = is.read(buffer)) != -1) {
						fos.write(buffer, 0, r);
					}
					fos.flush();
					fos.close();
					is.close();
					blob.free();
				}
			}catch (SQLException e) {
			e.printStackTrace();
			file = null;
		} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				file = null;
			} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}
		return file;
	}

	// (maxFileSize = 16177215) upload file's size up to 16MB
	public String upLoad(String studentID, String assignmentID,String submitTime,
			String fileName, InputStream inputStream) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "";
		try {
			conn = db.getConn();
			String sql = "insert into stu_course_assignment values (?,?,?,?,?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, studentID);
			pstmt.setString(2, assignmentID);
			pstmt.setString(3, submitTime);
			pstmt.setString(4, fileName);
			if (inputStream != null) {
				// fetches input stream of the upload file for the blob column
				pstmt.setBlob(5, inputStream);
			}
			pstmt.setString(6, "");
			if (pstmt.executeUpdate() > 0)
				feedback = "File uploaded";
		} catch (SQLException ex) {
			feedback = ex.getMessage();
			ex.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
	}

	public String deleteUpload(String studentID, String assignmentID) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String feedback = "";
		try {
			conn = db.getConn();
			sql = "delete from stu_course_assignment where studentID='"
					+ studentID + "' " + "and assignmentID='" + assignmentID
					+ "'";
			stmt = DB.getStatement(conn);
			DB.executeUpdate(stmt, sql);
			feedback = "File Success Deleted!";
		} finally {
			DB.close(stmt);
			DB.close(conn);
		}
		return feedback;
	}

	public Assignment getCurrentAssignment(String assignmentID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from course_assignment where assignmentID='"
				+ assignmentID + "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		Assignment assignment = new Assignment();
		try {
			while (rs.next()) {
				assignment = getAssignmentFromRs(rs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return assignment;
	}
	
	public String getUploadAssignmentName(String assignmentID,String studentID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from stu_course_assignment where assignmentID='"+ assignmentID + "' and studentID='"+studentID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		String fileName = "fileNotFound";
		try {
			if (rs.next()) {
				fileName= rs.getString("fileName");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return fileName;
	}
	
	public String getUploadAssignmentTime(String assignmentID,String studentID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from stu_course_assignment where assignmentID='"+ assignmentID + "' and studentID='"+studentID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		String fileName = "fileNotFound";
		try {
			if (rs.next()) {
				fileName= rs.getString("submitTime");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return fileName;
	}
	
	public String getUploadAssignmentMark(String assignmentID,String studentID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from stu_course_assignment where assignmentID='"+ assignmentID + "' and studentID='"+studentID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		String message = "SomeErrorHere";
		try {
			if (rs.next()) {
				message= rs.getString("teacherMark");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return message;
	}

	public List<Assignment> getStuAssignmentList(String studentID,
			String courseID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from course_assignment JOIN stu_course_assignment ON stu_course_assignment.assignmentID=course_assignment.assignmentID and course_assignment.courseID = '"
				+ courseID
				+ "' and stu_course_assignment.studentID='"
				+ studentID + "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Assignment> assignments = new ArrayList<Assignment>();
		try {
			while (rs.next()) {
				Assignment a = getAssignmentFromRs(rs);
				assignments.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return assignments;
	}

	private Assignment getAssignmentFromRs(ResultSet rs) {
		Assignment a = null;
		try {

			a = new Assignment();
			a.setAssignmentID(rs.getString("assignmentID"));
			a.setCourseID(rs.getString("courseID"));
			a.setAssignmentDeadline(rs.getDate("assignmentDeadline"));
			a.setAssignmentContent(rs.getString("assignmentContent"));

		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return a;
	}

	public String deleteAssignment(String assignmentID) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String feedback;
		try {
			conn = db.getConn();
			sql = "delete from course_assignment where assignmentID = '"
					+ assignmentID + "'";
			stmt = DB.getStatement(conn);
			DB.executeUpdate(stmt, sql);
			feedback = "Delete success!";
		} finally {
			DB.close(stmt);
			DB.close(conn);
		}
		return feedback;
	}

}
