package com.se.dao.impl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;
import java.sql.Time;

import javax.servlet.http.Part;

import com.mysql.jdbc.PreparedStatement;
import com.se.dao.SessionDao;
import com.se.model.Course;
import com.se.model.Session;
import com.se.model.User;

public class SessionDaoImpl implements SessionDao {

	private DB db = new DB();
	private Dbtools dbtools = new Dbtools();

	@Override
	public List<Session> getStudentRegisterSessionID(String studentID, String courseID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		
		String sql = "SELECT * FROM session JOIN student_participate ON session.sessionID=student_participate.sessionID and student_participate.studentID = '" + studentID+ "' and session.courseID='" + courseID+ "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Session> sessions = new ArrayList<Session>();
		try {
			while (rs.next()) {
				Session p = getSessionFromRs(rs);
				sessions.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return sessions;
	}

	public List<String> getStudentUploadedAssignmentID(String studentID,String courseID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		
		String sql = "SELECT stu_course_assignment.assignmentID FROM stu_course_assignment JOIN course_assignment ON "
				+ "course_assignment.assignmentID=stu_course_assignment.assignmentID and "
				+ "studentID='" + studentID + "' and course_assignment.courseID='"+courseID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<String> sessionIDs = new ArrayList<String>();
		try {
			while (rs.next()) {
				String p = rs.getString("sessionID");
				sessionIDs.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return sessionIDs;
	}

	public List<Session> getSessionList(String courseID) {
		// TODO Auto-generated method stub

		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from session where courseID = '" + courseID+ "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Session> sessions = new ArrayList<Session>();
		try {
			while (rs.next()) {
				Session p = getSessionFromRs(rs);
				sessions.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return sessions;
	}

	
	public Session getCurrentSession(String sessionID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from session where sessionID='" + sessionID
				+ "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		Session session = new Session();
		try {
			while (rs.next()) {
				session = getSessionFromRs(rs);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return session;
	}

	
	public boolean checkSessionPassword(String sessionID, String sessionPassword) {
		// TODO Auto-generated method stub

		List<Session> list = dbtools.executeQuery(Session.class,"select * from session where sessionID=? and sessionPassword=?",sessionID, sessionPassword);
		System.out.println("SessionList:" + list.size());
		if (list.size() > 0) {
			return true;
		}
		return false;
	}

	public boolean checkSessionParticipateList(String sessionID,
			String studentID) {
		// TODO Auto-generated method stub

		List<Session> list = dbtools.executeQuery(Session.class,"select * from student_participate where sessionID=? and studentID=?",
						sessionID, studentID);
		System.out.println("SessionParticipateList:" + list.size());
		if (list.size() > 0) {
			return true;
		}
		return false;
	}

	private Session getSessionFromRs(ResultSet rs) {
		Session s = null;
		try {

			s = new Session();
			s.setSessionID(rs.getString("sessionID"));
			s.setSessionAddress(rs.getString("sessionAddress"));
			s.setSessionType(rs.getString("sessionType"));
			s.setSessionPassword(rs.getString("sessionPassword"));
			s.setSessionDate(rs.getDate("sessionDate"));
			s.setSessionStartTime(rs.getTime("sessionstartTime"));
			s.setSessionEndTime(rs.getTime("sessionendTime"));
			s.setSessionContent(rs.getString("sessionContent"));
			s.setCourseID(rs.getString("courseID"));

		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public String participateToSession(String participateSessionID,
			String currentStudentID) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "";
		try {
			conn = db.getConn();
			String sql = "insert into student_participate values (?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, currentStudentID);
			pstmt.setString(2, participateSessionID);
			pstmt.executeUpdate();
			feedback = "Success participated to session with sessionID "
					+ participateSessionID;
		} catch (SQLException e1) {
			e1.printStackTrace();
			feedback = e1.getMessage();
		} catch (Exception e) {
			e.printStackTrace();
			feedback = e.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
	}

public String updateSession(Session s) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "Sorry some error here, check your courseID if it duplicated";
		try {
			conn = db.getConn();
			String sessionID = s.getSessionID();
			String sessionType = s.getSessionType();
			String sessionPassword = s.getSessionPassword();
			String sessionAddress = s.getSessionAddress();
			String sessionDate = new java.sql.Date (s.getSessionDate().getTime())+"";
			String sessionStartTime = new java.sql.Time(s.getSessionStartTime()
					.getTime())+"";
			String sessionEndTime = new java.sql.Time(s.getSessionEndTime()
					.getTime())+"";
			String sessionContent = s.getSessionContent();
		
			String sql = "update session set sessionType='"+sessionType+"',sessionPassword='"+sessionPassword+"',sessionAddress='"+sessionAddress+"'"
					+ ",sessionDate='"+sessionDate+"',sessionStartTime='"+sessionStartTime+"',sessionEndTime='"+sessionEndTime+"',sessionContent='"+sessionContent+"'"
							+ " where sessionID='"+sessionID+"'";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
		//	pstmt.setString(1, c.getCourseID());
//			pstmt.setString(2, c.getCourseName());
//			pstmt.setDate(1, new java.sql.Date (c.getCourseStartDate().getTime()));
//			pstmt.setDate(2, new java.sql.Date (c.getCourseEndDate().getTime()));
//			pstmt.setString(3, c.getCourseID());
			DB.executeUpdate(pstmt, sql);	
			conn.close();
			pstmt.close();
			
			feedback = "Updated Session Success";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			feedback=e.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
		
	}
	
	@Override
	public String addSession(Session session) {
		// TODO Auto-generated method stub

		// long fileLength = place.getLogo().length();

		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback;
		try {

			conn = db.getConn();
			String sql = "insert into session values (?,?,?,?, ?, ?,?,?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, session.getSessionID());
			pstmt.setString(2, session.getSessionType());
			pstmt.setString(3, session.getSessionPassword());
			pstmt.setString(4, session.getSessionAddress());
			pstmt.setDate(5, new java.sql.Date(session.getSessionDate()
					.getTime()));
			pstmt.setTime(6, new java.sql.Time(session.getSessionStartTime()
					.getTime()));
			pstmt.setTime(7, new java.sql.Time(session.getSessionEndTime()
					.getTime()));
			pstmt.setString(8, session.getSessionContent());
			pstmt.setString(9, session.getCourseID());
			// pstmt.setString(3, place.getLogoID());
			// pstmt.setBinaryStream(4, fInputStream,
			// (int)place.getLogo().length());

			pstmt.executeUpdate();
			feedback = "Session added successfully!";
		} catch (SQLException e1) {
			e1.printStackTrace();
			feedback = e1.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
	}

	@Override
	public String deleteSession(String sessionID) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String feedback ;
		try {
			conn = db.getConn();
			sql = "delete from session where sessionID = '" + sessionID + "'";
			stmt = DB.getStatement(conn);
			DB.executeUpdate(stmt, sql);
			feedback = "Delete success!";
		} finally {
			DB.close(stmt);
			DB.close(conn);
		}
		return feedback;
	}

}
