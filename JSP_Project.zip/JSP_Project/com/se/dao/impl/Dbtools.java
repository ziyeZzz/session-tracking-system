package com.se.dao.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.ResultSetHandler;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;



/**
 * Configuration file
 * connect to the mysql database 
 * Messages.java define the connection details
 * @author Zhou Ziye
 *
 */
public class Dbtools {
	private String ClassName=Messages.getString("Dbtools.className"); //$NON-NLS-1$
	private String user=Messages.getString("Dbtools.user"); //$NON-NLS-1$
	private String password=Messages.getString("Dbtools.password"); //$NON-NLS-1$
	private String url=Messages.getString("Dbtools.url"); //$NON-NLS-1$
	private Connection conn=null;
	
	public Connection getConn() {
		try {
			Class.forName(ClassName);
			conn=DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public int executeUpdate(String sql,Object...objects){
		int i=0;
		QueryRunner que=new QueryRunner();
		try {
			i=que.update(getConn(), sql, objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				
				if (conn!=null) {
					conn.close();
				}
				
			} catch (SQLException e) {
				// TODO: handle exception
//				System.out.println("<p>" + e.getMessage());
				e.printStackTrace();
			}
		}
		return i;
	}
	
	
	public List executeQuery(Class clazz,String sql,Object...objects){
		List list=new ArrayList();
		QueryRunner qr=new QueryRunner();
		ResultSetHandler res=new BeanListHandler(clazz);
		try {
			list=qr.query(getConn(), sql, res, objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				
				if (conn!=null) {
					conn.close();
				}
				
			} catch (SQLException e) {
				// TODO: handle exception
//				System.out.println("<p>" + e.getMessage());
				e.printStackTrace();
			}
		}
		return list;
	}

}
