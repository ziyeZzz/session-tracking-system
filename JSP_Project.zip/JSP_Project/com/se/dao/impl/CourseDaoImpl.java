package com.se.dao.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.PreparedStatement;
import com.se.dao.impl.DB;
import com.se.dao.CourseDao;
import com.se.model.Course;
import com.se.model.User;

public class CourseDaoImpl implements CourseDao {

	
	private DB db = new DB();
	@Override
	public List<Course> getStudentCourseList(String studentID) {
		// TODO Auto-generated method stub
		
		//List<Event> list = db.executeQuery(Event.class, "select * from event", objects);	
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "SELECT * FROM course JOIN course_student ON course.courseID=course_student.courseID and course_student.studentID = '" + studentID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Course> courses = new ArrayList<Course>();
		try {
			while (rs.next()) {
				Course c = getCourseFromRs(rs);
				courses.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return courses;
		
	}
	
	public List<Course> checkStudentCourse(String studentID,String courseID) {
		// TODO Auto-generated method stub
		
		//List<Event> list = db.executeQuery(Event.class, "select * from event", objects);	
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "SELECT * FROM course JOIN course_student ON course.courseID=course_student.courseID and course_student.studentID = '" + studentID+"' and course_student.courseID='"+courseID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Course> courses = new ArrayList<Course>();
		try {
			while (rs.next()) {
				Course c = getCourseFromRs(rs);
				courses.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return courses;
		
	}
	

	public List<Course> getTeacherCourseList(String teacherID) {
		// TODO Auto-generated method stub
		
		//List<Event> list = db.executeQuery(Event.class, "select * from event", objects);	
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "SELECT * FROM course where teacherID = '" + teacherID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<Course> courses = new ArrayList<Course>();
		try {
			while (rs.next()) {
				Course c = getCourseFromRs(rs);
				courses.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return courses;
		
	}
	
	public Course getCurrentCourse(String courseID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from course where courseID = '"+courseID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		
		Course course = new Course();
		try {
			while (rs.next()) {
				course = getCourseFromRs(rs);			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return course;
	}
	
	@Override
	public List<Course> searchCourseTeacher(String teacherID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from course where teacherID = '"+teacherID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		
		List<Course> courses = new ArrayList<Course>();
		try {
			while (rs.next()) {
				Course e = getCourseFromRs(rs);
				courses.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return courses;
	}

	@Override
	public String deleteCourse(String courseID) {
		// TODO Auto-generated method stub
	
		Connection conn = null;
		Statement stmt = null;
		String sql;
		String feedback;
		try {
			conn = db.getConn();
			sql = "delete from course where courseID = '" + courseID+"'";
			stmt = DB.getStatement(conn);
			DB.executeUpdate(stmt, sql);
			feedback = "Delete Success";
			return feedback;
		}finally {
			DB.close(stmt);
			DB.close(conn);		
		}
	}
	
	@Override
	public String addCourse(Course c) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback;
		try {
			conn = db.getConn();
			String sql = "insert into course values (?, ?, ?, ?,?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, c.getCourseID());
			pstmt.setString(2, c.getCourseName());
			pstmt.setDate(3, new java.sql.Date (c.getCourseStartDate().getTime()));
			pstmt.setDate(4, new java.sql.Date (c.getCourseEndDate().getTime()));
			pstmt.setString(5, c.getCourseRegisterPass());
			pstmt.setString(6, c.getTeacherID());			
			pstmt.executeUpdate();
			feedback = "Add Course Success";
			return feedback;
		} catch (SQLException e1) {
			e1.printStackTrace();
			feedback = e1.getMessage();
			return feedback;
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		
	}
	
public String updateCourse(Course c) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "Sorry some error here, check your courseID if it duplicated";
		try {
			conn = db.getConn();
			String courseID = c.getCourseID();
			String courseName = c.getCourseName();
			String courseRegisterPass = c.getCourseRegisterPass();
			Date sDate = new java.sql.Date (c.getCourseStartDate().getTime());
			String startDate = sDate+"";
			Date eDate = new java.sql.Date (c.getCourseEndDate().getTime());
			String endDate = eDate+"";
			
//			String sql = "update course set courseID= 11, course.courseName= 11, course.courseStartDate=?,course.courseEndDate=? where course.courseID='sss';";
			String sql = "update course set courseName='"+courseName+"',courseStartDate='"+startDate+"',courseEndDate='"+endDate+"',courseRegisterPass='"+courseRegisterPass+"' where courseID='"+courseID+"'";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
		//	pstmt.setString(1, c.getCourseID());
//			pstmt.setString(2, c.getCourseName());
//			pstmt.setDate(1, new java.sql.Date (c.getCourseStartDate().getTime()));
//			pstmt.setDate(2, new java.sql.Date (c.getCourseEndDate().getTime()));
//			pstmt.setString(3, c.getCourseID());
			DB.executeUpdate(pstmt, sql);	
			conn.close();
			pstmt.close();
			
			feedback = "Updated Course Success";
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			feedback=e.getMessage();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
		
	}
	
public Boolean checkCoursePass(String courseID,String courseRegisterPass) {
	
	Connection conn = db.getConn();
	Statement stmt = DB.getStatement(conn);
	String sql = "select * from course where courseID = '"+courseID+"'";
	ResultSet rs = DB.getResultSet(stmt, sql);
	String pass;
	Boolean flag = false;
	
	try {
		while (rs.next()) {
			pass=rs.getString("courseRegisterPass");
			if(pass.equals(courseRegisterPass))
				flag=true;
			else
				flag=false;
		}
	} catch (SQLException e) {
		e.printStackTrace();
	} finally {
		DB.close(stmt);
		DB.close(rs);
		DB.close(conn);
	}
	return flag;
}
	
	@Override
	public String registerToCourse(String courseID,String studentID) {
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		String feedback = "";
		try {
			conn = db.getConn();
			String sql = "insert into course_student values (?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, courseID);
			pstmt.setString(2, studentID);
			pstmt.executeUpdate();
			feedback = "Success Registered to course with courseID "+courseID;
		} catch (SQLException e1) {
			e1.printStackTrace();
			feedback = e1.getMessage();
		} catch (Exception e) {
			e.printStackTrace();
			feedback = e.getMessage();
		} 
		finally {
			DB.close(pstmt);
			DB.close(conn);
		}
		return feedback;
	}
	
	private Course getCourseFromRs(ResultSet rs) {
		Course c = null;
		try {
			c = new Course();
			c.setCourseID(rs.getString("courseID"));
			c.setCourseName(rs.getString("courseName"));
			c.setCourseStartDate(rs.getDate("courseStartDate"));
			c.setCourseEndDate(rs.getDate("courseEndDate"));
			c.setCourseRegisterPass(rs.getString("courseRegisterPass"));
			c.setTeacherID(rs.getString("teacherID"));
			
			
		} catch (SQLException e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
		return c;
	}









	

}
