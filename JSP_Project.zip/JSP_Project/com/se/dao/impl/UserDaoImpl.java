package com.se.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;










import com.mysql.jdbc.PreparedStatement;
//import com.opt.model.Student;
import com.se.dao.impl.Dbtools;
import com.se.dao.UserDao;
import com.se.model.Assignment;
import com.se.model.Course;
import com.se.model.User;


public class UserDaoImpl implements UserDao {
	
	private Dbtools dbtools=new Dbtools();
	private DB db = new DB();
	
	public boolean userLogin(User user) {
		// TODO Auto-generated method stub
		List<User> list=dbtools.executeQuery(User.class, "select * from user where userID=? and password=? and userType=?",user.getUserID(),user.getPassword(),user.getUserType());
		System.out.println("User Size:"+list.size());
		if(list.size()>0){
			return true;
		}return false;
	}
	@Override
	public List<User> getUserList() {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<User> users = new ArrayList<User>();
		try {
			while (rs.next()) {
				User a = getUserFromRs(rs);
				users.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return users;
		
	}
	
	public User getCurrentUser(String userID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user where userID='" + userID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		User user=new User();
		try {
			while (rs.next()) {
				user = getUserFromRs(rs);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return user;		
	}
	
	public User getCurrentUserByName(String userName) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user where userName='" + userName+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		User user=new User();
		try {
			while (rs.next()) {
				user = getUserFromRs(rs);				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return user;
		
	}
	
	public String getCurrentUserType(String userID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select userType from user where userID='" + userID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		String userType="";
		try {
			while (rs.next()) {
				userType = rs.getString("userType");				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return userType;
		
	}
	
	public List<User> getStuAssignmentList(String assignmentID) {
		// TODO Auto-generated method stub

		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user JOIN stu_course_assignment on user.userID=stu_course_assignment.studentID and stu_course_assignment.assignmentID = '" + assignmentID+ "'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<User> submitAssignmentStudents = new ArrayList<User>();
		try {
			while (rs.next()) {
				User a = getUserFromRs(rs);
				submitAssignmentStudents.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return submitAssignmentStudents;
	}
	
	public List<User> getCourseStudent(String courseID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user JOIN course_student on user.userID = course_student.studentID and course_student.courseID= '"+courseID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		
		List<User> users = new ArrayList<User>();
		try {
			while (rs.next()) {
				User e = getUserFromRs(rs);
				users.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return users;
	}
	
	public List<User> getSessionParticipateStudent(String sessionID) {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user JOIN student_participate on user.userID = student_participate.studentID and student_participate.sessionID= '"+sessionID+"'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		
		List<User> users = new ArrayList<User>();
		try {
			while (rs.next()) {
				User e = getUserFromRs(rs);
				users.add(e);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return users;
	}
	
	
	private User getUserFromRs(ResultSet rs) {
		User a = null;
		try {
			a = new User();
			a.setUserID(rs.getString("userID"));
			a.setUsername(rs.getString("username"));
			a.setPassword(rs.getString("password"));
			a.setUserType(rs.getString("userType"));
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return a;
	}



	@Override
	public void deleteUser(String userID) {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement stmt = null;
		String sql;
		try {
			conn = db.getConn();
			sql = "delete from user where userID = '" + userID+"'";
			stmt = DB.getStatement(conn);
			DB.executeUpdate(stmt, sql);
		} finally {
			DB.close(stmt);
			DB.close(conn);
		}
		
	}



	@Override
	public void addUser(User a) {
		// TODO Auto-generated method stub
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = db.getConn();
			String sql = "insert into user values (?, ?, ?,?)";
			pstmt = (PreparedStatement) DB.prepare(conn, sql);
			pstmt.setString(1, a.getUsername());
			pstmt.setString(2, a.getUserID());
			pstmt.setString(3, a.getPassword());
			pstmt.setString(4, a.getUserType());
			pstmt.executeUpdate();
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			DB.close(pstmt);
			DB.close(conn);
		}
	}

	public List<String> getTeacherUserList() {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select username from user where userType = 'teacher'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<String> teacherUsers = new ArrayList<String>();
		try {
			while (rs.next()) {
				String a = rs.getString("username");
				teacherUsers.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return teacherUsers;
		
	}
	
	public List<User> getStudentUserList() {
		// TODO Auto-generated method stub
		Connection conn = db.getConn();
		Statement stmt = DB.getStatement(conn);
		String sql = "select * from user where userType = 'student'";
		ResultSet rs = DB.getResultSet(stmt, sql);
		List<User> users = new ArrayList<User>();
		try {
			while (rs.next()) {
				User a = getUserFromRs(rs);
				users.add(a);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DB.close(stmt);
			DB.close(rs);
			DB.close(conn);
		}

		return users;
		
	}

	

}
