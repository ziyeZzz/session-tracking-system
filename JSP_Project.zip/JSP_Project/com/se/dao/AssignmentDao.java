package com.se.dao;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

import com.se.model.Assignment;


public interface AssignmentDao {

	public String addAssignment(String courseID,String assignmentID, Date assignmentDeadline,String assignmentContent);
	public List<Assignment> getAssignmentList(String courseID);
	public String deleteAssignment(String assignmentID);
	public List<Assignment> getStuAssignmentList(String studentID, String courseID);
	public Assignment getCurrentAssignment(String assignmentID);
	public String deleteUpload(String studentID, String assignmentID);
	public String upLoad(String studentID, String assignmentID,String nowDateTime, String fileName,InputStream inputStream);
	public File downLoad(String studentID, String assignmentID);
	public String getUploadAssignmentName(String assignmentID,String studentID);
	public String getUploadAssignmentTime(String assignmentID,String studentID);
	public String updateAssignment(Assignment a);
	public String getUploadAssignmentMark(String assignmentID,String studentID);
}
