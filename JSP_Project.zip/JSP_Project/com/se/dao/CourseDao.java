package com.se.dao;

import java.util.Date;
import java.util.List;

import com.se.model.Course;

public interface CourseDao {
	
	public List<Course> getStudentCourseList(String studentID);
	public String deleteCourse(String courseID);
	public String addCourse(Course e);
	public String updateCourse(Course c);
	public List<Course> searchCourseTeacher(String teacherID);
	public List<Course> getTeacherCourseList(String teacherID);
	public String registerToCourse(String courseID,String studentID);
	public Course getCurrentCourse(String courseID);
	public List<Course> checkStudentCourse(String studentID,String courseID);
	public Boolean checkCoursePass(String courseID,String courseRegisterPass);
	
}
